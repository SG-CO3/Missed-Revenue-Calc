import Calculator from "@/components/Calculator";

const Index = () => {
  // Example: Pre-fill from a form submission or URL params
  // In production, you'd read these from query params or POST data
  const contextData = {
    revenueRange: "$250k–$500k",
    crm: "Jobber",
    afterHours: "voicemail",
    frustrations: ["Missed calls on jobs", "Leads go cold"],
    goal: "More clients",
    budget: "Fits $1.3k/mo",
    timeline: "ASAP",
    readiness: "Yes",
  };

  return (
    <Calculator
      initialLocation="Austin, TX"
      initialBusinessType="Plumbing"
      contextData={contextData}
    />
  );
};

export default Index;
