import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { InfoIcon, Edit2Icon, PhoneIcon, MessageSquareIcon, CalendarIcon } from "lucide-react";

interface ContextData {
  revenueRange?: string;
  crm?: string;
  afterHours?: string;
  frustrations?: string[];
  goal?: string;
  budget?: string;
  timeline?: string;
  readiness?: string;
}

interface CalculatorProps {
  initialLocation?: string;
  initialBusinessType?: string;
  contextData?: ContextData;
}

const inquiryOptions = [
  { label: "0–50 calls/mo", value: 25 },
  { label: "50–100 calls/mo", value: 75 },
  { label: "100–200 calls/mo", value: 150 },
  { label: "200+ calls/mo", value: 250 },
];

const missedRateOptions = [
  { label: "Almost none", value: 0.05 },
  { label: "Some, here and there", value: 0.15 },
  { label: "Quite a few", value: 0.30 },
  { label: "Too many", value: 0.45 },
];

const BL = 0.30; // Fixed booking likelihood
const AI_MR = 0.02; // AI missed rate

export default function Calculator({
  initialLocation = "Your Area",
  initialBusinessType = "Your Business",
  contextData = {},
}: CalculatorProps) {
  const [location, setLocation] = useState(initialLocation);
  const [businessType, setBusinessType] = useState(initialBusinessType);
  const [monthlyInquiries, setMonthlyInquiries] = useState(75);
  const [missedRate, setMissedRate] = useState(0.15);
  const [avgJobValue, setAvgJobValue] = useState(1500);
  const [isEditing, setIsEditing] = useState(false);
  const [animateNumbers, setAnimateNumbers] = useState(false);

  // Trigger animation on value changes
  useEffect(() => {
    setAnimateNumbers(true);
    const timer = setTimeout(() => setAnimateNumbers(false), 200);
    return () => clearTimeout(timer);
  }, [monthlyInquiries, missedRate, avgJobValue]);

  // Calculations
  const currentMissedLeads = Math.round(monthlyInquiries * missedRate);
  const currentJobsLost = currentMissedLeads * BL;
  const currentLostRevenue = currentJobsLost * avgJobValue;

  const aiMissedLeads = Math.round(monthlyInquiries * AI_MR);
  const aiJobsLost = aiMissedLeads * BL;
  const revenueRecovered = Math.max(0, (currentJobsLost - aiJobsLost) * avgJobValue);

  const breakeven1300 = Math.ceil(1300 / avgJobValue);
  const breakeven3500 = Math.ceil(3500 / 3 / avgJobValue);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const handleCTAClick = (action: "book_demo" | "start_plan") => {
    window.dispatchEvent(
      new CustomEvent("calculatorAction", {
        detail: {
          location,
          business: businessType,
          L: monthlyInquiries,
          MR: missedRate,
          AOV: avgJobValue,
          BL,
          recoveredRevenue: revenueRecovered,
          action,
        },
      })
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Band A: Header */}
        <header className="mb-12 text-center">
          <h1 className="mb-4 text-4xl font-bold leading-tight text-foreground sm:text-5xl lg:text-6xl">
            How much revenue is{" "}
            <span className="bg-gradient-accent bg-clip-text text-transparent">{businessType}</span> in{" "}
            <span className="bg-gradient-accent bg-clip-text text-transparent">{location}</span> leaving on the
            table each month?
          </h1>
          <p className="mx-auto max-w-3xl text-lg text-muted-foreground sm:text-xl">
            Answering every lead fast wins the job—here's what missed calls are costing you (and how a 24/7 AI
            receptionist pays for itself).
          </p>
        </header>

        {/* Band B: Input Strip + Context Chips */}
        <div className="mb-12 grid gap-8 lg:grid-cols-3">
          {/* Left: Core Inputs */}
          <Card className="shadow-card lg:col-span-2">
            <CardContent className="space-y-6 p-6">
              <h2 className="text-xl font-semibold text-foreground">Your Business Details</h2>

              <div className="grid gap-6 sm:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Location / Service Area</label>
                  <Input
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="bg-background"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Business Type</label>
                  <Input
                    value={businessType}
                    onChange={(e) => setBusinessType(e.target.value)}
                    className="bg-background"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Monthly Inquiries</label>
                  <div className="flex gap-2">
                    <Select
                      value={monthlyInquiries.toString()}
                      onValueChange={(val) => {
                        setMonthlyInquiries(Number(val));
                        setIsEditing(false);
                      }}
                    >
                      <SelectTrigger className="bg-background">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {inquiryOptions.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value.toString()}>
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {!isEditing && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setIsEditing(true)}
                        className="shrink-0"
                      >
                        <Edit2Icon className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  {isEditing && (
                    <Input
                      type="number"
                      value={monthlyInquiries}
                      onChange={(e) => setMonthlyInquiries(Math.max(1, Number(e.target.value)))}
                      className="mt-2 bg-background"
                      placeholder="Custom value"
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Missed/Unanswered Rate</label>
                  <Select
                    value={missedRate.toString()}
                    onValueChange={(val) => setMissedRate(Number(val))}
                  >
                    <SelectTrigger className="bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {missedRateOptions.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value.toString()}>
                          {opt.label} ({Math.round(opt.value * 100)}%)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 sm:col-span-2">
                  <div className="flex items-center gap-2">
                    <label className="text-sm font-medium text-foreground">Average Job Value</label>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger>
                          <InfoIcon className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="text-sm">
                            We use a conservative 30% booking likelihood to estimate closed jobs; this stays
                            constant in both scenarios.
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                    <Input
                      type="number"
                      value={avgJobValue}
                      onChange={(e) => setAvgJobValue(Math.max(1, Number(e.target.value)))}
                      className="bg-background pl-7"
                      placeholder="1500"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Right: Context Chips */}
          <Card className="shadow-card">
            <CardContent className="space-y-4 p-6">
              <h3 className="text-lg font-semibold text-foreground">Context</h3>
              <div className="flex flex-wrap gap-2">
                {contextData.revenueRange && (
                  <Badge variant="secondary" className="text-xs">
                    Revenue: {contextData.revenueRange}
                  </Badge>
                )}
                {contextData.crm && (
                  <Badge variant="secondary" className="text-xs">
                    {contextData.crm !== "None" ? `Works with ${contextData.crm}` : "No CRM? We'll sync"}
                  </Badge>
                )}
                {contextData.afterHours && (
                  <Badge variant="secondary" className="text-xs">
                    Currently: {contextData.afterHours}
                  </Badge>
                )}
                {contextData.frustrations?.map((f, i) => (
                  <Badge key={i} variant="outline" className="border-accent text-accent text-xs">
                    {f}
                  </Badge>
                ))}
                {contextData.goal && (
                  <Badge variant="secondary" className="text-xs">
                    Goal: {contextData.goal}
                  </Badge>
                )}
                {contextData.budget && (
                  <Badge variant="secondary" className="text-xs">
                    {contextData.budget}
                  </Badge>
                )}
                {contextData.timeline && (
                  <Badge variant="secondary" className="text-xs">
                    Timeline: {contextData.timeline}
                  </Badge>
                )}
                {contextData.readiness && (
                  <Badge variant="secondary" className="text-xs">
                    Readiness: {contextData.readiness}
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Band C: Results */}
        <div className="mb-12 space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Today Card */}
            <Card className="shadow-card border-2 border-accent/20">
              <CardContent className="p-6">
                <div className="mb-4 flex items-center gap-2">
                  <div className="rounded-full bg-accent/10 p-2">
                    <PhoneIcon className="h-5 w-5 text-accent" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">Today (Current)</h3>
                </div>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Missed leads</p>
                    <p
                      className={`text-3xl font-bold text-accent transition-all ${
                        animateNumbers ? "scale-105 opacity-50" : "scale-100 opacity-100"
                      }`}
                    >
                      {currentMissedLeads}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Potential jobs lost</p>
                    <p
                      className={`text-3xl font-bold text-accent transition-all ${
                        animateNumbers ? "scale-105 opacity-50" : "scale-100 opacity-100"
                      }`}
                    >
                      {currentJobsLost.toFixed(1)}
                    </p>
                  </div>
                  <div className="border-t border-border pt-4">
                    <p className="text-sm text-muted-foreground">Lost revenue (per month)</p>
                    <p
                      className={`text-4xl font-bold text-accent transition-all ${
                        animateNumbers ? "scale-105 opacity-50" : "scale-100 opacity-100"
                      }`}
                    >
                      {formatCurrency(currentLostRevenue)}
                    </p>
                  </div>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <p>Inquiries: {monthlyInquiries}</p>
                    <p>Missed rate: {Math.round(missedRate * 100)}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* With AI Card */}
            <Card className="shadow-card border-2 border-success/20">
              <CardContent className="p-6">
                <div className="mb-4 flex items-center gap-2">
                  <div className="rounded-full bg-success/10 p-2">
                    <MessageSquareIcon className="h-5 w-5 text-success" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">With 24/7 AI Receptionist</h3>
                </div>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Missed leads</p>
                    <p
                      className={`text-3xl font-bold text-success transition-all ${
                        animateNumbers ? "scale-105 opacity-50" : "scale-100 opacity-100"
                      }`}
                    >
                      {aiMissedLeads}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Potential jobs lost</p>
                    <p
                      className={`text-3xl font-bold text-success transition-all ${
                        animateNumbers ? "scale-105 opacity-50" : "scale-100 opacity-100"
                      }`}
                    >
                      {aiJobsLost.toFixed(1)}
                    </p>
                  </div>
                  <div className="border-t border-border pt-4">
                    <p className="text-sm text-muted-foreground">Revenue recovered (per month)</p>
                    <p
                      className={`text-4xl font-bold text-success transition-all ${
                        animateNumbers ? "scale-105 opacity-50" : "scale-100 opacity-100"
                      }`}
                    >
                      {formatCurrency(revenueRecovered)}
                    </p>
                  </div>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <p>Answers instantly by phone/SMS/web chat</p>
                    <p>Integrates with {contextData.crm || "your calendar"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Impact Bar */}
          <Card className="bg-gradient-success shadow-card">
            <CardContent className="p-6">
              <div className="text-center">
                <p className="mb-2 text-sm font-medium text-success-foreground/80">
                  Extra revenue captured monthly
                </p>
                <p
                  className={`mb-4 text-5xl font-bold text-success-foreground transition-all ${
                    animateNumbers ? "scale-105 opacity-50" : "scale-100 opacity-100"
                  }`}
                >
                  {formatCurrency(revenueRecovered)}
                </p>
                <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-success-foreground/90">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-success-foreground/20 text-success-foreground">
                      Breakeven (Monthly $1,300): ~{breakeven1300} jobs
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-success-foreground/20 text-success-foreground">
                      Breakeven (3-mo $3,500): ~{breakeven3500} jobs/mo
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Band D: Offer + CTA */}
        <Card className="shadow-card border-2 border-accent/20">
          <CardContent className="space-y-8 p-8">
            <div className="text-center">
              <p className="mb-6 text-xl font-semibold text-foreground">
                Fix the leak for a fraction of the loss—set up in ~72 hours.
              </p>

              <div className="mx-auto mb-8 grid max-w-2xl gap-6 sm:grid-cols-2">
                <Card className="border-2 border-primary">
                  <CardContent className="p-6 text-center">
                    <p className="mb-2 text-sm text-muted-foreground">Plan A</p>
                    <p className="mb-1 text-4xl font-bold text-foreground">$1,300</p>
                    <p className="text-sm text-muted-foreground">/month (cancel anytime)</p>
                  </CardContent>
                </Card>

                <Card className="border-2 border-success">
                  <CardContent className="relative p-6 text-center">
                    <Badge className="absolute -top-3 right-4 bg-success text-success-foreground">
                      Save ~$400
                    </Badge>
                    <p className="mb-2 text-sm text-muted-foreground">Plan B</p>
                    <p className="mb-1 text-4xl font-bold text-foreground">$3,500</p>
                    <p className="text-sm text-muted-foreground">for 3 months</p>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <Button
                  size="lg"
                  className="bg-gradient-accent text-lg font-semibold hover:opacity-90"
                  onClick={() => handleCTAClick("book_demo")}
                >
                  <CalendarIcon className="mr-2 h-5 w-5" />
                  Book a 10-min AI Demo
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 text-lg font-semibold"
                  onClick={() => handleCTAClick("start_plan")}
                >
                  Start 3-Month Plan ($3,500)
                </Button>
              </div>

              <p className="mt-6 text-sm text-muted-foreground">
                We'll set this up for <span className="font-semibold text-foreground">{businessType}</span> in{" "}
                <span className="font-semibold text-foreground">{location}</span>
                {contextData.goal && (
                  <>
                    {" "}
                    to hit your goal: <span className="font-semibold text-foreground">{contextData.goal}</span>
                  </>
                )}
              </p>

              <div className="mt-6 flex flex-wrap justify-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <PhoneIcon className="h-4 w-4 text-accent" />
                  <span>Human-like voice with your exact script</span>
                </div>
                <div className="flex items-center gap-2">
                  <MessageSquareIcon className="h-4 w-4 text-accent" />
                  <span>24/7 coverage incl. nights/weekends</span>
                </div>
                <div className="flex items-center gap-2">
                  <CalendarIcon className="h-4 w-4 text-accent" />
                  <span>Works with {contextData.crm || "no CRM"}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Mobile Sticky CTA */}
        <div className="fixed bottom-0 left-0 right-0 border-t border-border bg-card p-4 shadow-card lg:hidden">
          <Button
            size="lg"
            className="w-full bg-gradient-accent text-lg font-semibold hover:opacity-90"
            onClick={() => handleCTAClick("book_demo")}
          >
            <CalendarIcon className="mr-2 h-5 w-5" />
            Book a 10-min AI Demo
          </Button>
        </div>
      </div>
    </div>
  );
}
